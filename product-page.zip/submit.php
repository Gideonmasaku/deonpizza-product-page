<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars($_POST['fullname']);
    $email = htmlspecialchars($_POST['email']);
    $comment = htmlspecialchars($_POST['comment']);

    $entry = "Name: $name\nEmail: $email\nComment: $comment\n---\n";
    file_put_contents("comments.txt", $entry, FILE_APPEND);

    header("Location: thankyou.html");
    exit();
} else {
    echo "Invalid request.";
}
?>
